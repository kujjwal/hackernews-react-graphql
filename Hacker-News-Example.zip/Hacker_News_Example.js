const waysToAskForNews = [
    'Read (me|) the news',
    'What is the news (today|)',
];
var i;
var headlines;

let newsReadContext = context(() => {
    intent(waysToAskForNews, p => {
        p.play({"command": "initialNewsReq"});
        p.play('The first three headlines are,');
        headlines = p.visual.headlines;
        console.log('asked for news first time');
        for (i = 0; i < 3; i++) {
            p.play({"command": "highlightTitle", "title": headlines[i]});
            p.play(headlines[i]);
        }
        p.play('Should I continue reading? (You can tell me to open articles by their number|)');
    });
    
    follow('(Yes|Continue|Sure)', p => {
        headlines = p.visual.headlines;
        console.log('asked for news next time');
        const steps = i + 3;
        for (; i < steps; i++) {
            p.play({"command": "highlightTitle", "title": headlines[i]});
            p.play(headlines[i]);
        }
        p.play('Should I continue reading?');
    });
    
    follow('(No|Stop)', p => {
        p.play('Okay. (I can open an article by its number if you say Open Article number X|)');
    });
});

intent('Open (link|article|number|) $(NUMBER)', p => {
    p.play(`Opening article number ${p.NUMBER.value}`);
    p.play({"command": "openLink", "value": p.NUMBER.value});
});

const howDoesThisWork = [
    'How (do|does) (you|this) work?',
    'What (do|does) (you|this) do?', 
    'How do I use (you|this)?',
];

question(howDoesThisWork, p => {
 p.play('You can tell me to read the news, or ask me what the news is today. To navigate pages, say Take me to, Bring up, or Go to whichever page you would like.');
});


intent('(Show|Let me see|Bring up|Go to|Take me to|) (the|) $(D Next|New|Home|Show|Comments|Ask|Jobs) (HN|) (page|)', p => {
    if (p.D.value == 'Ask' || p.D.value == 'Show') {
        p.play(`Taking you to the ${p.D.value} H N page. You can ask me to read the news from there.`, `Taking you to the ${p.D.value} H N page.`, `Taking you to the ${p.D.value} H N page.`);
    }
    else if (p.D.value == 'Jobs') {
        p.play('Taking you to the Y Combinator jobs page. You can ask me to read the news from there.', 'Taking you to the Y Combinator jobs page.', 'Taking you to the Y Combinator jobs page.');
    }
    else {
        p.play(`Taking you to the ${p.D.value} page. You can ask me to read the news from there.`, `Taking you to the ${p.D.value} page.`, `Taking you to the ${p.D.value} page.`);
    }
    p.play({"command": p.D.value});
});